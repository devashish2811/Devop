<?php

$URL="https://restcountries.eu/rest/v1/all";

$my_file = 'data.json';


// if (file_exists($my_file)) {
//     $handle = fopen($my_file, 'r');
//     $data = fread($handle,filesize($my_file));
// } else {
//     $ch= curl_init();
//     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//     curl_setopt($ch, CURLOPT_URL, $URL);
//     curl_setopt($ch, CURLOPT_HEADER, false);

//     $result= curl_exec($ch);
//     curl_close($ch);
//     $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
//     fwrite($handle, $result);
//     $data = fread($handle,filesize($my_file));
// }


// var_dump(json_decode($data));

var_dump(filesize($my_file));