<?php
$s = "Fred:Corwill;Wilfred:Corwill;Barney:Tornbull;Betty:Tornbull;Bjon:Tornbull;Raphael:Corwill;Alfred:Corwill";
function meeting($s) {
    $s = strtoupper($s);
return $s;
}

echo meeting($s);

?>
