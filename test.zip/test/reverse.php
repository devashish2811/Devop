<?php
$a="ashu";$b="";

for($i=strlen($a)-1; $i>=0; $i--)
{
$b.=$a[$i];
}

echo $b;

?>
