<?php 
session_start();
include 'include/class.user.php';

if (isset($_POST['submit'])) {
    extract($_POST);
    $user = new User();
    $login= $user->check_login($emailusername,$password);

    if ($login) {
        header("location:home.php");
    }else{
        echo "Wrong username or password";
    }
}

 ?>

 <!DOCTYPE html>
 <html>
 <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>OOP LOGIN MODULE</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
 </head>
 <body>
    <div id="container" class="container">
      <h1>Login Here</h1>
      <form action="" method="post" name="login">
        <table class="table " width="400">
          <tr>
            <th>UserName or Email:</th>
            <td>
              <input type="text" name="emailusername" required>
            </td>
          </tr>
          <tr>
            <th>Password:</th>
            <td>
              <input type="password" name="password" required>
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>
              <input class="btn" type="submit" name="submit" value="Login" onclick="return(submitlogin());">
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><a href="registration.php">Register new user</a></td>
          </tr>

        </table>
      </form>
    </div>
 </body>
 <!-- <script>
     function submitlogin() {
        if (form.emailusername.value == "") {
            alert("Enter Email or UserName");
            return false;
        }else if(form.password.value == ""){
            alert("Enter Password");
            return false;
        }
     }
 </script> -->
 </html>