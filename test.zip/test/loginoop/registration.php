<?php 
include_once 'include/class.user.php';
session_start();
$user= new User();
// if (!$user->get_session()) {
//   header('location:login.php');
// }

if (isset($_POST['submit'])) {
	extract($_POST);
	$register= $user->register($fullname,$uname,$uemail,$upass);
	if($register){
		echo "<h3>Registration Successful. <a href='login.php'>Login</a></h3>";
	}else{
		echo "<h3>Username or email already exist.</h3>";
	}
}


 ?>


 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=edge">
 	<title>Registration OOP</title>
 	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
 </head>
 <body>
 	<div id="container" class="container">
      <h1>Registration Here</h1>
      <form action="" method="post" name="reg">
        <table class="table">
          <tr>
            <th>Full Name:</th>
            <td>
              <input type="text" name="fullname" required>
            </td>
          </tr>
          <tr>
            <th>User Name:</th>
            <td>
              <input type="text" name="uname" required>
            </td>
          </tr>
          <tr>
            <th>Email:</th>
            <td>
              <input type="email" name="uemail" required>
            </td>
          </tr>
          <tr>
            <th>Password:</th>
            <td>
              <input type="password" name="upass" required>
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>
              <input class="btn" type="submit" name="submit" value="Register" onclick="return(submitreg());">
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><a href="login.php">Already registered? Click Here!</a></td>
          </tr>

        </table>
      </form>
    </div>
 </body>
 </html>