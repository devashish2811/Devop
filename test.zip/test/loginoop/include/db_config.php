<?php 
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', 'root');
define('DB_DB', 'swadeshi');

class DB_con{
	public $connection;

	public function __construct()
	{
		$this->connection= new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DB);
		if ($this->connection->connect_error) {
			die('Database Error: '.$this->connection->connect_error);
		}
	}

	public function ret_obj()
	{
		return $this->connection;
	}
}


 ?>