<?php 
include 'db_config.php';

class User{
	public $db;
	// Initiate Database connection
	public function __construct()
	{
		$this->db= new DB_con();
		$this->db= $this->db->ret_obj();
	}

	// User Registration
	public function register($name,$username,$email,$password)
	{
		// check if the email or username already exist
		$checkquery="SELECT uid FROM users WHERE uname='$username' OR uemail='$email'";
		$result=$this->db->query($checkquery);
		$data=$result->fetch_array(MYSQLI_ASSOC);
		$count_row=$result->num_rows;
		// If not exist then insert
		if ($count_row == 0) {
			$query="INSERT INTO users(fullname, uname, uemail, upass) VALUES('$name', '$username', '$email', '$password')";
			$insert= $this->db->query($query);
			return true;
		}else{
			return false;
		}
	}

	// Check login
	public function check_login($emailusername, $password)
	{
		$password= md5($password);
		$query="SELECT uid FROM users WHERE uname='$emailusername' OR uemail='$emailusername' AND upass='$password'";

		$result= $this->db->query($query);
		$data=$result->fetch_array(MYSQLI_ASSOC);
		$count_row= $result->num_rows;
		
		if ($count_row == 1) {
			$_SESSION['login']= true;
			$_SESSION['uid']= $data['uid'];
			return true;
		}else{
			return false;
		}
	}

	// Get full name of user via Id
	public function get_fullname($uid)
	{
		$query="SELECT fullname FROM users WHERE uid='$uid'";
		$result= $this->db->query($query);
		$data= $result->fetch_array(MYSQLI_ASSOC);
		return $data['fullname'];
	}

	// Logout the user
	public function logout()
	{
		$_SESSION['login']= false;
		unset($_SESSION);
		session_destroy();
	}

	// Check login session
	public function get_session()
	{
		return $_SESSION['login'];
	}
}




 ?>