<?php 
include 'include/class.user.php';
session_start();
$uid= $_SESSION['uid'];

$user= new User();
if (!$user->get_session()) {
  header('location:login.php');
}

if (isset($_GET['q']) && $_GET['q'] ==  'logout') {
  $user->logout();
  header('location:login.php');
}
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=edge">
 	<title>OOP Home</title>
 	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
 </head>
 <body>
 	<div id="container" class="container">
      <div id="header">
        <a href="home.php?q=logout">LOGOUT</a>
      </div>
      <div id="main-body">
        <br/>
        <br/>
        <br/>
        <br/>
        <h1>
          Hello <?php echo $user->get_fullname($uid); ?>
		</h1>
      </div>
      <div id="footer"></div>
    </div>
 </body>
 </html>