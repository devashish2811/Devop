<?php 
$string = "can a can simple can simple can a simple";
$new = [];
$array = explode(' ',$string);
$count = count($array);
for($i=0; $i<$count; $i++)
{
  for($j=$i; $j<$count-$i; $j++)
  {
    if($array[$i] == $array[$j])
    {
      $new[$i][$array[$i]] += 1;
      unset($array[$j]);
    }
  }
}

print_r($new);

?>
