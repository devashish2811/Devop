<?php
$con= mysqli_connect('localhost', 'database_user_name', 'database_password', 'database_name');

if (isset($_POST['login'])) {
    $email= $_POST['email'];
    $password= $_POST['password'];

    $query= "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $run= mysqli_query($con,$query);

    if(mysqli_num_rows($run) == 1){
        $result=mysqli_fetch_assoc($run);
        var_dump($result);
    }else{
        echo 'Record not found';
    }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login Page</title>
</head>
<body>
    <form method="post">
        <label for="">Email</label>
        <input type="email" name="email"><br>
        
        <label for="">Password</label>
        <input type="password" name="password">

        <input type="submit" name="login" value="Login">
    </form>
</body>
</html>