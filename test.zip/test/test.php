<?php

$arr1=['P','T','T','P','T'];        //k=1 r=2
$arr2=['T','T','P','P','T','P'];    //k=2 r=3
$arr3=['P','T','P','T','T','P'];    //k=3 r=3


// $arr=$arr1; $k=1;
$arr=$arr2; $k=2;
// $arr=$arr3; $k=3;


$length=count($arr); $catch=0; 

for ($y=$length-1; $y >= 0; $y--) { 
    if ($arr[$y] == 'P') {
        for ($z=$y; $z >= $y-$k; $z--) { 
            if ($arr[$z] == 'T') {
                $catch++;
                $arr[$z]='BX';
                $arr[$y]='BHP';
                break;
            }
        }
    }
}

for ($i=0; $i < $length; $i++) {
    if ($arr[$i] == 'P') {
        for ($j=$i; $j <= $i+$k; $j++) {
            if ($j < $length) {
                if($arr[$j] == 'T'){
                    $catch++;
                    $arr[$j]='X';
                    $arr[$i]='HP';
                    break;
                }
            }
        }
    }
}


print_r($arr);
echo $catch;

